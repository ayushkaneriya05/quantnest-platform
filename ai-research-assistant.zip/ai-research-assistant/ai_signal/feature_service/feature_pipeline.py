import json
from pathlib import Path
import pandas as pd
import numpy as np
from pymongo import MongoClient
from ta.momentum import RSIIndicator
from ta.trend import EMAIndicator, SMAIndicator
from loguru import logger

# === Config ===
MONGO_URI = "mongodb://localhost:27017"
DB_NAME = "quantnest_marketdata"
BATCH_SIZE = 5000

# === MongoDB ===
client = MongoClient(MONGO_URI)
db = client[DB_NAME]

def resample_to_15m(df: pd.DataFrame) -> pd.DataFrame:
    """
    Resample 1m candles to 15m OHLCV.
    """
    df = df.resample("15min").agg({
        "open": "first",
        "high": "max",
        "low": "min",
        "close": "last",
        "volume": "sum"
    }).dropna()
    return df

def compute_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add technical indicators on resampled 15m bars.
    """
    df["return"] = df["close"].pct_change()
    df["sma_5"] = SMAIndicator(df["close"], 5).sma_indicator()
    df["ema_10"] = EMAIndicator(df["close"], 10).ema_indicator()
    df["rsi"] = RSIIndicator(df["close"], 14).rsi()
    df["volatility"] = df["return"].rolling(20).std()
    df["lag_return_15m"] = df["return"].shift(1)
    return df

def process_and_store(df: pd.DataFrame, instrument: str):
    """
    Convert DataFrame rows to feature docs and insert into Mongo.
    """
    feature_docs = []
    for ts, row in df.iterrows():
        if pd.isna(row["sma_5"]) or pd.isna(row["ema_10"]) or pd.isna(row["rsi"]):
            continue
        feature_docs.append({
            "instrument": instrument,
            "timestamp": ts.to_pydatetime(),
            "sma_5": float(row["sma_5"]),
            "ema_10": float(row["ema_10"]),
            "rsi": float(row["rsi"]),
            "volatility": float(row["volatility"]) if not pd.isna(row["volatility"]) else 0.0,
            "lag_return_15m": float(row["lag_return_15m"]) if not pd.isna(row["lag_return_15m"]) else 0.0,
        })

    if feature_docs:
        db.feature_snapshot.insert_many(feature_docs)
        logger.info(f"Inserted {len(feature_docs)} 15m features for {instrument}")

def run_pipeline(instrument="NSE:ABB-EQ"):
    """
    Main pipeline: fetch 1m candles → resample → compute features → save.
    """
    query = {
        "instrument": instrument,
        "resolution": "1m",
    }

    logger.info(f"Fetching 1m candles for {instrument}")
    cursor = db.candles.find(query).sort("timestamp", 1)

    batch = []
    for doc in cursor:
        batch.append(doc)
        if len(batch) >= BATCH_SIZE:
            df = pd.DataFrame(batch)
            df["timestamp"] = pd.to_datetime(df["timestamp"])
            df.set_index("timestamp", inplace=True)
            df = resample_to_15m(df)
            df = compute_features(df)
            process_and_store(df, instrument)
            batch = []

    # process last batch
    if batch:
        df = pd.DataFrame(batch)
        df["timestamp"] = pd.to_datetime(df["timestamp"])
        df.set_index("timestamp", inplace=True)
        df = resample_to_15m(df)
        df = compute_features(df)
        process_and_store(df, instrument)

    logger.success(f"✅ Finished feature pipeline for {instrument} (15m bars)")

BASE_DIR = Path(__file__).resolve().parent.parent
nifty100_path = BASE_DIR /"data"/"nifty100_symbols.json"
nifty100_data = json.loads(nifty100_path.read_text())

if __name__ == "__main__":
    for t in nifty100_data:
        symbol = t["symbol"]
        instrument = f"NSE:{symbol}-EQ"
        run_pipeline(instrument)
