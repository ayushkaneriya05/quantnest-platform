# ==============================
# AI Research Assistant - Global Model Training
# ==============================

import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
import joblib
from motor.motor_asyncio import AsyncIOMotorClient
import asyncio

MONGO_URI = "mongodb://localhost:27017"
DB_NAME = "quantnest_marketdata"
FEATURE_COLLECTION = "feature_snapshot"
MODEL_PATH = "../models/current.xgb"

# --------------------------
# 1. Load Features from Mongo (async → sync wrapper)
# --------------------------
async def load_features():
    client = AsyncIOMotorClient(MONGO_URI)
    db = client[DB_NAME]
    cursor = db[FEATURE_COLLECTION].find({})
    docs = []
    async for doc in cursor:
        docs.append(doc)
    return pd.DataFrame(docs)

df = asyncio.run(load_features())
print("Loaded features:", df.shape)
print(df.head())

# --------------------------
# 2. Preprocess
# --------------------------
# Drop Mongo _id
if "_id" in df.columns:
    df = df.drop(columns=["_id"])

# Convert timestamp
df["timestamp"] = pd.to_datetime(df["timestamp"])

# Encode instrument as categorical
df["instrument"] = df["instrument"].astype("category").cat.codes

# Target: define a simple label (next close > current close → BUY=1 else SELL=0)
df["target"] = (df["close"].shift(-1) > df["close"]).astype(int)

# Drop last row (no target)
df = df.dropna()

# Features
feature_cols = [c for c in df.columns if c not in ["timestamp", "target"]]
X = df[feature_cols]
y = df["target"]

print("Features:", feature_cols)

# --------------------------
# 3. Train/Test Split
# --------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, shuffle=False
)

# --------------------------
# 4. Train XGBoost Model
# --------------------------
dtrain = xgb.DMatrix(X_train, label=y_train)
dtest = xgb.DMatrix(X_test, label=y_test)

params = {
    "objective": "binary:logistic",
    "eval_metric": "logloss",
    "max_depth": 5,
    "eta": 0.1,
    "subsample": 0.8,
    "colsample_bytree": 0.8,
    "seed": 42,
}

watchlist = [(dtrain, "train"), (dtest, "eval")]
model = xgb.train(params, dtrain, num_boost_round=200, evals=watchlist, early_stopping_rounds=20)

# --------------------------
# 5. Evaluate
# --------------------------
y_pred = (model.predict(dtest) > 0.5).astype(int)
print("Accuracy:", accuracy_score(y_test, y_pred))
print(classification_report(y_test, y_pred))

# --------------------------
# 6. Save Model
# --------------------------
model.save_model(MODEL_PATH)
print(f"✅ Model saved to {MODEL_PATH}")
