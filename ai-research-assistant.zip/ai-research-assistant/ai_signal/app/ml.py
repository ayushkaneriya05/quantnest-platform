import xgboost as xgb
import pandas as pd
import joblib
from loguru import logger
from datetime import datetime, timedelta
from motor.motor_asyncio import AsyncIOMotorClient

MODEL_PATH = "models/current.xgb"
MONGO_URI = "mongodb://localhost:27017"
DB_NAME = "quantnest_marketdata"
FEATURE_COLLECTION = "feature_snapshot"

# --------------------------
# Global Variables
# --------------------------
model = None
instrument_map = {}  # mapping instrument → category code
inverse_map = {}     # reverse mapping for debug

# --------------------------
# Load model
# --------------------------
def load_model():
    global model
    try:
        model = xgb.Booster()
        model.load_model(MODEL_PATH)
        logger.info(f"✅ Loaded model from {MODEL_PATH}")
    except Exception as e:
        logger.error(f"❌ Could not load model: {e}")
        model = None

# --------------------------
# Build Instrument Map (from DB)
# --------------------------
async def build_instrument_map():
    global instrument_map, inverse_map
    client = AsyncIOMotorClient(MONGO_URI)
    db = client[DB_NAME]
    cursor = db[FEATURE_COLLECTION].distinct("instrument")
    instruments = await cursor
    instrument_map = {inst: idx for idx, inst in enumerate(sorted(instruments))}
    inverse_map = {v: k for k, v in instrument_map.items()}
    logger.info(f"Built instrument map for {len(instrument_map)} instruments")

# --------------------------
# Get Latest Features for Instrument
# --------------------------
async def get_latest_features(instrument: str):
    client = AsyncIOMotorClient(MONGO_URI)
    db = client[DB_NAME]
    doc = await db[FEATURE_COLLECTION].find_one(
        {"instrument": instrument},
        sort=[("timestamp", -1)]
    )
    if not doc:
        return None

    # drop non-features
    ignore_cols = ["_id", "timestamp"]
    feat = {k: v for k, v in doc.items() if k not in ignore_cols}

    # inject encoded instrument
    feat["instrument"] = instrument_map.get(instrument, -1)

    return pd.DataFrame([feat])

# --------------------------
# Predict Signal
# --------------------------
async def predict_signal(instrument: str):
    if model is None:
        load_model()

    if not instrument_map:
        await build_instrument_map()

    df = await get_latest_features(instrument)
    if df is None:
        return {"error": f"No features found for {instrument}"}

    dmatrix = xgb.DMatrix(df)
    prob = float(model.predict(dmatrix)[0])
    signal = "BUY" if prob > 0.5 else "SELL"

    return {
        "instrument": instrument,
        "signal": signal,
        "confidence": round(prob if prob > 0.5 else 1 - prob, 3),
        "timestamp": datetime.utcnow().isoformat()
    }
