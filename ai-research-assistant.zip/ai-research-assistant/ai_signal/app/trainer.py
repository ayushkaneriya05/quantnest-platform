import pandas as pd
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
from motor.motor_asyncio import AsyncIOMotorClient
import asyncio
from loguru import logger

MODEL_PATH = "models/current.xgb"
MONGO_URI = "mongodb://localhost:27017"
DB_NAME = "quantnest_marketdata"
FEATURE_COLLECTION = "feature_snapshot"


# --------------------------
# Async Loader for Features
# --------------------------
async def _load_features():
    client = AsyncIOMotorClient(MONGO_URI)
    db = client[DB_NAME]
    cursor = db[FEATURE_COLLECTION].find({})
    docs = []
    async for doc in cursor:
        docs.append(doc)
    return pd.DataFrame(docs)


# --------------------------
# Training Logic
# --------------------------
def train_model():
    logger.info("🚀 Starting model training...")
    df = asyncio.run(_load_features())
    logger.info(f"Loaded {df.shape[0]} feature rows")

    if df.empty:
        logger.error("No features found in DB")
        return

    # Drop Mongo _id
    if "_id" in df.columns:
        df = df.drop(columns=["_id"])

    # Convert timestamp
    df["timestamp"] = pd.to_datetime(df["timestamp"])

    # Encode instrument as categorical
    df["instrument"] = df["instrument"].astype("category").cat.codes

    # Define target (next close > current close)
    df["target"] = (df["close"].shift(-1) > df["close"]).astype(int)

    # Drop last row (NaN target)
    df = df.dropna()

    # Features (exclude timestamp + target)
    feature_cols = [c for c in df.columns if c not in ["timestamp", "target"]]
    X = df[feature_cols]
    y = df["target"]

    logger.info(f"Using {len(feature_cols)} features: {feature_cols}")

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, shuffle=False
    )

    # XGBoost dataset
    dtrain = xgb.DMatrix(X_train, label=y_train)
    dtest = xgb.DMatrix(X_test, label=y_test)

    params = {
        "objective": "binary:logistic",
        "eval_metric": "logloss",
        "max_depth": 5,
        "eta": 0.1,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "seed": 42,
    }

    watchlist = [(dtrain, "train"), (dtest, "eval")]

    # Train model
    model = xgb.train(
        params,
        dtrain,
        num_boost_round=200,
        evals=watchlist,
        early_stopping_rounds=20,
    )

    # Evaluate
    y_pred = (model.predict(dtest) > 0.5).astype(int)
    acc = accuracy_score(y_test, y_pred)
    logger.info(f"✅ Training complete. Accuracy={acc:.3f}")
    logger.debug("\n" + classification_report(y_test, y_pred))

    # Save model
    model.save_model(MODEL_PATH)
    logger.info(f"📦 Model saved at {MODEL_PATH}")

    return MODEL_PATH
