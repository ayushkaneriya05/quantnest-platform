"""Main FastAPI app: endpoints for /health, /predict, /bulk_predict, /train, /models
"""
import os
from fastapi import FastAPI, HTTPException, BackgroundTasks, Depends
from datetime import datetime
from typing import List

from app.models import PredictRequest, PredictResponse, BulkPredictRequest, BulkPredictResponse, TrainRequest
from app.feature_store import get_features_for, bulk_get_features, insert_ai_signal
from app.ml import get_model
from app.auth import require_service_api_key
from app.utils import explain_with_shap, cache_get, cache_set, size_from_prob

app = FastAPI(title="fastapi-signal-mongo")
MODEL_VERSION = os.getenv("MODEL_VERSION", "v1")

@app.get("/health")
def health():
    return {"status": "ok", "time": datetime.utcnow().isoformat() + "Z"}

@app.post("/predict", response_model=PredictResponse)
def predict(req: PredictRequest, authorized: bool = Depends(require_service_api_key)):
    # 1) get features
    if req.features:
        features = req.features
        ts = req.ts or datetime.utcnow()
    else:
        if not req.ts:
            raise HTTPException(status_code=400, detail="ts required if features not provided")
        features = get_features_for(req.symbol, req.ts.isoformat())
        if features is None:
            raise HTTPException(status_code=404, detail=f"No features for {req.symbol} @ {req.ts}")
        ts = req.ts
    # 2) try cache
    cache_key = f"sig:{req.symbol}:{ts.isoformat()}"
    cached = cache_get(cache_key)
    if cached:
        return cached
    # 3) predict
    model = get_model()
    prob = model.predict_proba(features)
    size = size_from_prob(prob)
    signal = 1 if prob > 0.55 else (-1 if prob < 0.45 else 0)
    # 4) explain
    expl = []
    try:
        expl = explain_with_shap(model.booster, features, model.feature_order)
    except Exception:
        expl = []
    resp = {
        "symbol": req.symbol,
        "ts": ts,   
        "model_version": MODEL_VERSION,
        "prob_up": float(prob),
        "signal": int(signal),
        "size": float(size),
        "explain": expl,
        "raw": {"features_count": len(features)}
    }
    # cache short time
    cache_set(cache_key, resp, ex=30)
    # persist into mongo ai_signal collection (non-blocking could be used)
    try:
        insert_ai_signal(req.symbol, ts.isoformat(), MODEL_VERSION, prob, signal, size, expl, {"features_count": len(features)})
    except Exception:
        pass
    return resp

@app.post("/bulk_predict", response_model=BulkPredictResponse)
def bulk_predict(req: BulkPredictRequest, authorized: bool = Depends(require_service_api_key)):
    # build item list for feature fetch
    items = []
    for it in req.items:
        if it.features:
            items.append({"symbol": it.symbol, "ts": (it.ts.isoformat() if it.ts else datetime.utcnow().isoformat()), "features": it.features})
        else:
            if not it.ts:
                raise HTTPException(status_code=400, detail="ts required if features not provided")
            items.append({"symbol": it.symbol, "ts": it.ts.isoformat()})
    # fetch features in bulk for those without inline features
    lookup_items = [ {"symbol": it["symbol"], "ts": it["ts"]} for it in items if "features" not in it ]
    fetched = bulk_get_features(lookup_items) if lookup_items else {}
    results = []
    model = get_model()
    for it in items:
        if "features" in it:
            features = it["features"]
            ts = it["ts"]
        else:
            key = f"{it['symbol']}|{it['ts']}"
            features = fetched.get(key)
            ts = it["ts"]
            if features is None:
                # return a minimal not-found placeholder
                results.append({
                    "symbol": it["symbol"],
                    "ts": ts,
                    "model_version": MODEL_VERSION,
                    "prob_up": 0.0,
                    "signal": 0,
                    "size": 0.0,
                    "explain": [],
                    "raw": {"features_count": 0}
                })
                continue
        prob = model.predict_proba(features)
        size = size_from_prob(prob)
        signal = 1 if prob > 0.55 else (-1 if prob < 0.45 else 0)
        expl = explain_with_shap(model.booster, features, model.feature_order)
        results.append({
            "symbol": it["symbol"],
            "ts": ts,
            "model_version": MODEL_VERSION,
            "prob_up": float(prob),
            "signal": int(signal),
            "size": float(size),
            "explain": expl,
            "raw": {"features_count": len(features)}
        })
        # persist each prediction
        try:
            insert_ai_signal(it["symbol"], ts, MODEL_VERSION, prob, signal, size, expl, {"features_count": len(features)})
        except Exception:
            pass
    return {"results": results}

@app.post("/train")
def train(req: TrainRequest, background_tasks: BackgroundTasks, authorized: bool = Depends(require_service_api_key)):
    # For safety, training runs in background by default
    from app.trainer import train_and_export
    if req.async_mode:
        background_tasks.add_task(train_and_export)
        return {"status": "training_started"}
    else:
        train_and_export()
        return {"status": "training_completed"}

@app.get("/models")
def models_list(authorized: bool = Depends(require_service_api_key)):
    # simple model info endpoint
    return {"model_version": MODEL_VERSION, "model_path": os.getenv("MODEL_PATH", "/app/models/current.xgb")}
